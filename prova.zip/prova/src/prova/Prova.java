/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package prova;

/**
 *
 * @author Windows
 */
public class Prova {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Janela painel =    new Janela(); 
        painel.setVisible(true);
        painel.pack();
        painel.setLocationRelativeTo(null); // Centraliza a janela no ecrã do usuario
    }
    
}
