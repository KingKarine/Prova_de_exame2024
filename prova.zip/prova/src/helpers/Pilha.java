/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package helpers;

/**
 *
 * @author Windows
 */
public class Pilha {
    private int[] elementos;
    private int topo;

    public Pilha(int tamanhoMaxximo) {
        elementos = new int[tamanhoMaxximo];
        topo = -1;
    }
    
    public boolean isEmpty(){
        return topo < 0;
    }
    
    public void push(int elemento) throws Exception {
        if(topo >= elementos.length - 1){
            throw new Exception(); 
        }
        elementos[++topo] = elemento;
    }
    
    public int pop(){
        if(topo < 0){
            return -1; 
        }
        return elementos[--topo];
    }
    
    public int peek(){
        if(topo < 0){
            return -1; 
        }
        return  elementos[topo];
       
    }
    
    /**
     *
     */
    @Override
     public String toString(){
        StringBuilder sb = new StringBuilder();
        for (int i = topo; i >= 0; i--){
            sb.append(elementos[i]);
        }
        return sb.toString();
    }
}
