
package helpers;



public class ListaEncadeada {
   private No cabeca;
   private int tamanho;

    public ListaEncadeada() {
        this.cabeca = null;
        this.tamanho = 0;
    }
   
   public boolean esvaziar(){
      return tamanho == 0;
   }
   
   public void inserirInicio(int valor){
        No novoNo = new No(valor);
        novoNo.setProximo(cabeca);
        cabeca = novoNo;
        tamanho++;
   }
   
   public int removerInicio(){
        if (this.esvaziar()){
            return -1;
        } else {
            int dadoRemovido = cabeca.getValor();
            cabeca = cabeca.getProximo();
            tamanho--;
            return dadoRemovido;
        }
        
   }
   
   public int no(){
       No noActual = cabeca;  
       return noActual.getValor();
   }
   
   public No Proximo(){
       No noActual = cabeca;  
       return noActual.getProximo();
   }
    
}
