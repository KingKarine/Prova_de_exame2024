/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package helpers;

import java.util.ArrayList;

/**
 *
 * @author Windows
 */


public class Arvore {
   private ArrayList arvore;

    public Arvore() {
        this.arvore = new ArrayList<>();
    }
   
    public void inserir(int elemeneto){
        arvore.add(elemeneto);
    }
    
    public int raiz(){
        return (int) arvore.get(0);
    }
    
    public int filhoMaisEsquerda(int indeceRaiz ){
        int elemento = indeceRaiz - 1;
        return (int) arvore.get(elemento);
    }
    
    public int filhoMaisDireito(int indeceRaiz){
        int elemento = indeceRaiz + 1;
        return (int) arvore.get(elemento);
    }
    
     @Override
     public String toString(){
        StringBuilder sb = new StringBuilder();
        for (Object i : arvore){
            sb.append(arvore.get((int) i));
        }
        return sb.toString();
    }
   
}
